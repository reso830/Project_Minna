# Handoff: Feature CRUD (Add / Update / Remove Feature)

## Overview
Adds create, update, and delete flows for "features" within a project in the Minna sidebar. Users can add a new feature to a project via a popover off the project row's "+" icon, and edit/remove an existing feature via a pencil icon that appears on hover over each feature row.

## About the Design Files
The files in this bundle are **design references built in HTML/JS** (a single-file interactive prototype), not production code to copy directly. The task is to recreate this design in the target codebase's existing environment (React, Vue, native, etc.) using its established component patterns, state management, and styling system.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and interaction behavior shown are final — recreate pixel-perfectly using the codebase's existing libraries where equivalents exist.

## Screens / Views

### 1. Project row — hover affordances
- Each project row (sidebar) shows project name, and on hover reveals two 18×18px icon buttons, right-aligned, in order: overflow menu (⋯, 3 dots) then "+" (add feature).
- Icons: `opacity:0;pointer-events:none` by default, `opacity:1` on row hover. Icon color `#7c8983`, hover background `rgba(0,0,0,.08)`, border-radius 4px.
- Clicking "+" opens a popover anchored below-right of the icon with a single item: **"Add Feature"** (pencil-style list item, hover bg `#eceff0`).
- Clicking the item opens the Add Feature modal (see below).

### 2. Feature row — hover affordance (pencil / edit)
- Each feature row (indented 20px under its project) shows: status-color dot (6px circle), 3-digit display ID (`#8f9a94`), title (truncates with CSS ellipsis, `flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap` — never let the icon get pushed off / collide with text).
- On row hover, an 18×18px **pencil icon** fades in at the right edge (same opacity/pointer-events pattern as project icons). Icon is a stroked pencil (2px stroke, round caps), color `currentColor` (~`#4a544d`/row text color).
- Clicking the pencil opens the same modal as Add Feature, but in **"Update Feature"** mode (see below), pre-filled with that feature's data.
- Row list is data-driven (not hardcoded), so newly created features appear immediately in the correct project.

### 3. Add / Update Feature modal (shared)
Whole-page blocking modal, centered, `520px` wide, `max-height:86vh`, white background, `10px` border-radius, `28px` padding, `20px` gap between field groups.

Header:
- Title: `"Add Feature"` or `"Update Feature"` depending on mode — 18px/600 IBM Plex Sans, `#0f1512`.
- Subtitle: project name, 12px JetBrains Mono, `#8f9a94`.

All field groups use a uniform 20px vertical gap between them (no group-specific margin overrides).

Fields (top to bottom):
1. **FEATURE NUMBER** — label style used throughout: 11px/600 JetBrains Mono, `#7c8983`, letter-spacing .8px. Value shown in a read-only, non-editable box (`#f3f5f4` bg, `1px solid #dbe0dd` border, 6px radius, 9px/10px padding, 13px/500 JetBrains Mono `#4a544d`). Value = next sequential 3-digit number for that project when adding (max existing + 1, zero-padded), or the feature's existing number when updating (never editable).
2. **FEATURE TITLE** — label, sub-label (12px IBM Plex Sans, `#8f9a94`) reads "Limit to 5 words or less. Choose carefully as it can't be updated later." in **add mode only** (hidden in update mode). Single-line text input (50 char maxlength), placeholder "e.g. Refund flow redesign", char counter bottom-right (`n/50`, 11px JetBrains Mono `#b7bdba`). **Disabled/read-only in update mode** (grayed `#f3f5f4` bg, `#a7afac` text, `cursor:not-allowed`) — title can only be set once, at creation.
3. **FEATURE DESCRIPTION** — same label style, sub-label "Brief description of this feature." (always shown, both modes). Single-line text input, 100 char maxlength, placeholder "e.g. Lets users retry failed payments automatically", char counter bottom-right (`n/100`). Editable in both add and update modes.
4. **FEATURE DETAILS** — same label style, `6px` gap to the tab row below. Two tabs, underline style (`2px solid` bottom border when active, color `#00c9d6`; inactive text `#8f9a94`, active text `#0f1512`):
   - **"Type here"** (default/active tab): multi-line textarea, 2500 char maxlength, min-height 110px, resizable vertically, placeholder "Describe what this feature should do...", char counter bottom-right (`n/2500`).
   - **"Attach MD file"**: file picker — "Choose File" button (outlined, `#dbe0dd` border, hover bg `#f3f5f4`) + filename label ("No file selected" when empty), truncates with ellipsis.
   - Only one tab's content is visible at a time; switching tabs preserves both field values.

Footer (same row, `justify-content:space-between`):
- Left: **"Remove Feature"** button — red primary (`#a13030` bg, white text, hover `#8a2828`) — **only visible in Update mode** (hidden entirely when adding a new feature).
- Right: **"Discard"** (gray secondary — white bg, `1px solid #dbe0dd` border, `#4a544d` text, hover bg `#f3f5f4`) and **"Save"** (primary, cyan `#00c9d6` bg / `#0f1512` text when enabled, hover `#00F0FF`; disabled state — form not dirty — is `#dfe6e2` bg, `#a7afac` text, `cursor:not-allowed`), placed side-by-side, Save last.

**Dirty check**: form is dirty if title, brief, or filename differ from their original values (empty strings when adding; the feature's existing values when updating). Save is disabled until dirty.

### 4. Discard confirmation modal
Triggered only when Discard is clicked **and** the form is dirty (clicking Discard on a clean form closes immediately, no confirmation). Whole-screen blocking overlay, centered card (380px), title "Discard this feature?", body "You have unsaved changes. Discard them?", buttons: "Keep Editing" (outlined) / "Discard" (red `#a13030`, right-most).

### 5. Remove Feature confirmation modal
Triggered by the Remove Feature button. Whole-screen blocking overlay, centered card (400px), title `Remove "<feature title>"?`, body "This removes the feature and its journal entries. This can't be undone.", buttons: "Cancel" (outlined) / "Remove Feature" (red `#a13030`, right-most). Confirming deletes the feature from its project's list and, if it was the currently-selected feature in the journal view, falls back to selecting feature `001`.

## Interactions & Behavior
- Popovers (project "+", feature pencil) are anchored via the clicked icon's live screen position (`getBoundingClientRect()`) and rendered with `position:fixed` so they always draw above all other content — including rows below the fold inside the scrollable project list — and are never clipped by the list's scroll container or hidden behind the avatar block at the bottom of the sidebar.
- Only one popover/menu can be open at a time; clicking anywhere outside closes it (backdrop click).
- Clicking a feature's overflow icon does not also trigger the row's "select feature" click (stopPropagation).
- On successful "Add," the modal closes, the new feature is inserted (status `parked`) into the correct project's list, the project auto-expands, and the app navigates to the journal view for that new feature.
- On successful "Update," only the feature's title/brief/attachment/slug are changed — status, phase, and journal thread are untouched.

## State Management
Suggested state shape (adapt to the target framework):
- `addFeatureMode`: `'create' | 'update'`
- `addFeatureProject`: project key being targeted
- `addFeatureEditingId`: feature id being edited (update mode only)
- `addFeatureTitle`, `addFeatureDescription`, `addFeatureBrief`, `addFeatureFileName`: draft field values
- `addFeatureOriginal`: snapshot of `{title, description, brief, fileName}` at open-time, used for the dirty check
- `addFeatureTab`: `'brief' | 'attachment'`
- `menuAnchor`: `{top, right}` screen coordinates for the currently open popover
- Per-project/per-feature hover state to reveal the "+"/pencil icons

## Design Tokens
- Font families: IBM Plex Sans (UI text), IBM Plex Mono (secondary/mono text), JetBrains Mono (labels, headers, mono UI)
- Colors: background `#f3f5f4`/`#eceff0`, borders `#dbe0dd`, muted text `#8f9a94`/`#7c8983`/`#4a544d`, primary text `#0f1512`, cyan accent `#00c9d6` (hover `#00F0FF`), destructive `#a13030` (hover `#8a2828`), disabled `#dfe6e2`/`#a7afac`
- Status dot colors: parked `#9a9a94`, active `#00c9d6`, blocked `#7a1f30`, closed `#2f9e44`
- Border radius: 4–6px for buttons/inputs/icons, 10px for modal cards
- Modal overlay: `rgba(15,21,18,.55–.65)`

## Assets
No new image assets. Icons are inline stroked SVGs (24×24 viewBox): plus/cross (add), pencil (edit), overflow dots (existing project menu) — all built with `stroke="currentColor"`, no filled art.

## Files
- `Minna Prototype.dc.html` — full interactive prototype containing this flow (and the rest of the Minna app shell). Search for `addFeatureToggle_`, `openAddFeatureModal`, `openUpdateFeatureModal`, `saveAddFeature`, and `sidebarRowsFor` to find the relevant logic.
