# Handoff: Journal View — Details Section

## Overview
Adds an assignee avatar and a hover/pin "Details" panel to the journal view's title bar, and switches feature naming from English titles to slugs in both the title bar and sidebar.

## About the Design Files
The bundled HTML file is a **design reference** built as an interactive HTML prototype — it shows intended look and behavior, not production code to copy directly. Recreate these designs in the target codebase's existing environment (React, Vue, SwiftUI, native, etc.) using its established components and patterns. If no environment exists yet, choose the most appropriate framework and implement there.

## Fidelity
**Low/medium-fidelity wireframe.** Colors, spacing, and icons are illustrative placeholders (especially agent avatar colors) — apply the target codebase's existing design system for final styling, while preserving the structure and interactions described below.

## Screens / Views

### Journal View — Title Bar
- **Purpose:** Header for a single feature's journal/chat thread. Shows identity (assignee, ID, slug), status, and phase, and exposes an on-demand Details panel.
- **Layout:** Single row, 54px tall, horizontal flex, `padding: 0 24px`, `gap: 12px`, bottom border `2px solid #dbe0dd`, `align-items: center`.
- **Components (left to right):**
  1. **Assignee avatar** — 32×32px, `border-radius: 6px`, flex none.
     - Minna assigned: background `#00c9d6` (lightning blue), centered white Minna mark icon at 26×26px (`object-fit: contain`).
     - Agent assigned: solid background of the agent's placeholder color (e.g. `#e08a2e`, `#4a544d`, `#c0392b`), centered 2-letter agent code in white, `font: 700 11px 'JetBrains Mono'`.
  2. **ID + slug** — `<span>` for numeric ID in `#8f9a94`, `font: 14px 'JetBrains Mono'`, `margin-right: 8px`, followed by the feature **slug** (e.g. `payment-retries`) in `#0f1512`, `font: 600 17px 'JetBrains Mono'`. (Previously showed the English title, e.g. "Payment retries" — now always the slug.)
  3. Spacer (`margin-left: auto`).
  4. **Status chip** — existing status pill, unchanged.
  5. **Phase chip** ("TASKS" or similar) — existing pill, unchanged, `border: 1px solid #dbe0dd`, `color: #4a544d`, `padding: 5px 14px`, `border-radius: 4px`, `font: 700 12px 'JetBrains Mono'`.
  6. **Details icon button** — 22×22px, `border-radius: 6px`, `color: #7c8983` at rest. On hover: background `#7c8983`, icon color `#eceff0` (same hover treatment as the board-view/sidebar icon buttons). Icon swaps between:
     - Default: outline "i" info icon (circle + dot + stroke), 15×15px.
     - When the Details panel is visible (hovering or pinned): a star/badge pin icon (thumbtack shape, not a map pin), same size — visually indicates "this can be pinned / is pinned."

### Journal View — Details Panel
- **Purpose:** Quick-glance summary of the feature without leaving the thread.
- **Trigger:** Appears on mouse-enter of the Details icon OR the panel itself (so moving from icon to panel doesn't dismiss it); disappears on mouse-leave of both, unless pinned. Clicking the icon toggles a pinned state that keeps it open regardless of hover.
- **Layout:** Sits directly below the title bar, **in normal document flow** (not absolutely positioned/overlaid) — it pushes the chat thread down rather than covering it. No drop shadow. Background `#fff`, bottom border `1px solid #dbe0dd`, `padding: 18px 24px`, vertical flex, `gap: 16px`.
- **Content — 3 rows:**
  1. Two columns, `gap: 32px`: **ID** and **Title**, each a labeled field (label: `font: 600 11px 'JetBrains Mono'`, color `#8f9a94`, letter-spacing `.8px`, uppercase; value: `font: 400 13px 'IBM Plex Sans'`, color `#0f1512`).
  2. Two columns, same spacing: **Type** and **Assignee** (assignee value: "Minna" or the agent's name).
  3. Single full-width column: **Description**, value `line-height: 1.5`.
- **Per-thread scoping:** The panel's hover/pinned state is local to the currently open feature. Switching to a different feature (via sidebar or opening a new journal) always resets the panel to hidden/unpinned — it must never carry over or apply globally across features.
- **Thread resize behavior:** The chat thread below is a normal flexed, scrollable column. When the Details panel mounts/unmounts, the thread container shrinks/grows accordingly (flexbox reflow, no manual height math). To prevent the newest (bottom-most) message from being scrolled out of view when the panel appears, the thread scroll position is programmatically reset to `scrollHeight` (scrolled to bottom) whenever the panel's visibility toggles.

## Sidebar
- Each feature row's label now shows the **slug** (e.g. `cart-drawer-refactor`) instead of the English title (e.g. "Cart drawer refactor"). No other changes to row layout, icons, or hover behavior.

## Interactions & Behavior Summary
- Hover Details icon → panel opens, icon becomes pin.
- Hover panel itself → stays open (no flicker moving from icon to panel).
- Mouse leaves both icon and panel, not pinned → panel closes, icon reverts to "i".
- Click icon → toggles pinned state; pinned panel stays open regardless of hover.
- Switch selected feature → panel state (hover + pinned) resets to closed.
- Panel open/close → thread auto-scrolls to bottom.

## Design Tokens
- Assignee/Minna background: `#00c9d6`
- Placeholder agent colors: `#e08a2e`, `#4a544d`, `#c0392b` (extend this palette as more agents are added)
- Icon default color: `#7c8983`; icon hover background: `#7c8983`; icon hover foreground: `#eceff0`
- Border/divider: `#dbe0dd`
- Text primary: `#0f1512`; text secondary/label: `#8f9a94`
- Fonts: `JetBrains Mono` (IDs, slugs, labels, chips), `IBM Plex Sans` (Details panel values)

## Assets
- `assets/minna-white-icon.png` — white Minna mark used on the lightning-blue assignee avatar when Minna is the assignee. Sourced from user-provided upload (`Minna_White.png`).
- Agent avatars are text-only placeholders (colored tile + 2-letter code); no image assets yet — real agent avatar imagery is a future step per the user.

## Files
- `Minna Prototype.dc.html` — full prototype containing this feature (journal view title bar, Details panel, sidebar slugs) alongside the rest of the app.
- `assets/minna-white-icon.png` — Minna avatar asset referenced above.
