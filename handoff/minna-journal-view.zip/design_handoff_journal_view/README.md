# Handoff: Minna Journal View

## Overview
Minna is an AI agent orchestrator. The Journal View is the primary working screen: a left sidebar listing projects/features, a center "journal" thread showing the running conversation/decision log for the selected feature, and a right panel showing live agent terminal output, the plan markdown, and a code diff.

## About the Design Files
The bundled file (`Minna Prototype.dc.html`) is a **design reference built in HTML** — an interactive prototype showing intended layout, states, and behavior. It is not production code. The task is to recreate this design in the target codebase's existing environment (React, Vue, etc. — whichever the app already uses) following its established component patterns, state management, and styling system. If no frontend environment exists yet, choose the framework best suited to the project.

## Fidelity
**Low-to-medium fidelity wireframe.** Colors, spacing, and typography are illustrative, not final brand values — treat this as a structural/behavioral guide. Apply the target codebase's existing design system for exact colors, type scale, and component styling. Layout proportions, information hierarchy, and interaction patterns should be preserved closely.

## Screens / Views (this handoff covers Journal View only)
Note: the full prototype also has a Board (kanban) view and an empty/blank state, reached via a toggle in the sidebar header. This handoff package documents **only the Journal View** — the default view when a project has activity.

### Layout
Three-column layout, fixed 1400×880 frame in the prototype (production should be fluid/responsive):
1. **Left sidebar** (280px fixed) — projects list + agent usage
2. **Center panel** (flex:1) — journal thread for the selected feature
3. **Right panel** (490px fixed) — agent terminal / MD / DIFF tabs

## Left Sidebar
- Header row: logo mark (44×44px) + "minna" wordmark (700 17px JetBrains Mono) + icon buttons (view toggle, settings/gear) aligned right, gap 8px.
- "PROJECTS" label (700 11px JetBrains Mono, letter-spacing 1.2px, color #7c8983) with a "+" add button aligned right.
- Scrollable project list. Each **project row**: chevron (▾/▸) + project name (500 13px JetBrains Mono) + a "+" (add feature) icon that is hidden by default and appears on row hover (opacity 0→1). Row states:
  - Selected: background #00F0FF, text #0f1512
  - Has a blocked child + collapsed: background #f7ecc8 (amber), text #4a544d
  - Default: transparent background, text #4a544d
- Expanding a project reveals its **feature rows**, indented 20px, each with: a 6px colored status dot, a 3-digit id in muted gray (#8f9a94), and the feature slug/name. Row states mirror project row states (selected = #dfe6e2 bg; blocked = amber tint #f7ecc8/#f2dfa8).
- Below the list: a divider, a square avatar placeholder (dynamic, 1:1 aspect), then a collapsible "AGENT USAGE" section (chevron toggle) showing per-agent colored swatch + two horizontal usage bars (5h / 7d) with percentage fill in #00c9d6 on a #dfe6e2 track.

### Projects & Features data model (from the prototype)
- Checkout Redesign: 001 Cart drawer refactor (active), 002 Payment retries (blocked — needs decision), 003 Empty state copy (closed)
- Search Revamp: 001 Fuzzy match ranking (parked), 002 Search analytics (parked)
- Billing v2: 001 Invoice PDF export (blocked — needs decision), 002 Proration logic (parked)
- Notifications: 001 Digest emails (parked)

Status → color mapping: parked=#dbe0dd/#4a544d text, active=#00F0FF/#101614 text, blocked=#7a1f30/#fff text, closed=#2f9e44/#fff text.

## Center Panel — Journal Thread
- Header bar (54px, border-bottom 2px #dbe0dd): feature id (muted) + slug (600 17px JetBrains Mono), right-aligned status pill + a "TASKS" outline button.
- Scrollable message thread. Each message: 32×32px avatar square with initials (minna = dark bg #0f1512/cyan text #00F0FF; agent = orange bg #e08a2e/dark text), sender name + timestamp (500 12px JetBrains Mono, muted), and a message bubble (bg #e5e9e6, border-radius 4px, padding 14px 16px, 400 13px IBM Plex Sans, line-height 1.5).
- **Decision prompts**: when a message includes a pending decision, render two outline buttons below the bubble text (border/text #00c9d6, hover fills #00F0FF bg + dark text). Once answered, replace with a single resolved pill showing "✓ {chosen answer}" — this state is permanent per feature (stored per-session, not per-message).
- Footer: reply input (flex:1, border #dbe0dd, radius 4px) + send button (40×40px, cyan #00c9d6 bg, hover #00F0FF, arrow icon). Enter key submits, matching the input's onKeyDown behavior. Below the input row: single-line truncated git info string, e.g. "(a1c9e42) feat/{slug}".

## Right Panel — Agent Detail
- Tab bar (54px): AGENTS / MD / DIFF. Active tab: bg #00F0FF, text #101614, 600 13px JetBrains Mono. Inactive: bg #eceff0, text #8f9a94, 400 weight; hover fills dark bg #101614 + cyan text #00F0FF (MD/DIFF tabs only in the prototype — normalize across all three in production).
- Panel background is dark (#0c110f) for all three tabs.
- **AGENTS tab**: stacked, individually collapsible agent panes (chevron toggle). Each pane header: chevron + "agent-N · {status}" label, color-coded by status (working=#e08a2e orange, idle=#8f9a94 gray). Expanded pane shows a small terminal-style log (monospace, colored per line type — e.g. cyan for commands, light gray for file diffs, muted for waiting states). Only one or more panes may be expanded at once (independent toggles, not accordion-exclusive).
- **MD tab**: renders the feature's plan.md as monospace text with a heading and a bullet list (dark bg, cyan heading, light gray body).
- **DIFF tab**: renders a unified diff view — filename heading, then colored lines: gray for hunk headers (@@ ... @@), green (#7cf28c) for additions, red (#e07a7a) for removals, light gray for unchanged context. Monospace font throughout.

## Interactions & Behavior
- Clicking a project row: toggles its expand/collapse (does not change the active feature).
- Clicking a feature row: selects that feature and updates the entire journal + right panel to its data.
- Hovering a project row reveals its "+" add-feature icon (click currently a no-op placeholder — wire to a "create feature" flow).
- Agent panes, project rows, and the usage section each expand/collapse independently and persist only for the current session.
- Decision buttons: clicking either option resolves the decision permanently for that feature/session (no undo in the prototype — consider whether production needs one).
- Reply input and Enter-to-send pattern should be reused consistently (same input+send-button pattern appears in the blank-state view of the broader prototype, if referenced later).

## State Management
Suggested state shape per feature/project (see `features` and `projectNames`/`featureProjectMap` objects in the DC's logic class for the exact source data used in this handoff):
- `selectedFeatureId`
- per-project `expanded: boolean`
- per-agent-pane `expanded: boolean`
- `activeRightTab: 'agents' | 'md' | 'diff'`
- `replyText: string`
- `decisionAnswer: string | null` per feature (or per decision message, if a feature can have more than one over time)
- `hoveredProjectId` (or CSS-only hover in production — the prototype uses JS state only because inline styles can't do parent-hover-affects-child; a real CSS stylesheet can use `:hover .add-icon` instead)

## Design Tokens (as used in the prototype — treat as placeholders, not final)
**Colors:** background #f3f5f4 (app), #eceff0 (sidebar), #0c110f (dark panel); text #0f1512 (primary), #4a544d (secondary), #8f9a94 (muted), #7c8983 (icon default); accent cyan #00c9d6 / bright cyan #00F0FF; status amber #f7ecc8/#f2dfa8, blocked red #7a1f30, closed green #2f9e44, working orange #e08a2e; borders #dbe0dd, #b7bdba.
**Typography:** JetBrains Mono (headings, labels, UI chrome), IBM Plex Sans (message body text), IBM Plex Mono (usage/empty-state small text). Weights 400/500/600/700 as annotated per element above.
**Spacing:** sidebar padding 20px 16px; panel header height 54px; message thread padding 22px 24px; row padding 6-7px 8-9px; row border-radius 5-6px; button/pill border-radius 4px.
**Borders/shadows:** 1px #dbe0dd dividers; 2px #dbe0dd under panel headers; outer frame shadow 0 8px 30px rgba(0,0,0,.18), radius 10px (prototype-only chrome, not part of the real app surface).

## Assets
- `minna-mark.png` — logo mark used at 44px (header) size in this view. Location: `assets/minna-mark.png` in the bundle.
- All icons are inline SVG (Feather-style outline icons) — no icon font/library dependency.

## Files
- `Minna Prototype.dc.html` — full interactive prototype (all views: Journal, Board, blank state). Journal View is the default state on load.
